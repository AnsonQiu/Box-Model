[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/IkSlepvv)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=12951642&assignment_repo_type=AssignmentRepo)
# Assignment 8: File Systems

In this assignment, you will add support for large files and symbolic links to the xv6 file system.

Before you start coding, read "Chapter 8: File System" of the [xv6 book](https://pdos.csail.mit.edu/6.828/2023/xv6/book-riscv-rev3.pdf), and study the corresponding code.


## Tasks

### 1. Add support for large files

In this task, you will increase the maximum possible size of an xv6 file. Currently, xv6 files are limited to 268 blocks, totaling `268*BSIZE` bytes per file (`BSIZE` is 1024 in xv6). This limit comes from the fact that an xv6 inode contains 12 "direct" block numbers and one "singly-indirect" block number, which refers to a block that holds up to 256 more block numbers, for a total of 12+256=268 blocks. (See Fig. 8.3 in the [xv6 book](https://pdos.csail.mit.edu/6.828/2023/xv6/book-riscv-rev3.pdf)).

The `bigfile` command in xv6 creates the largest file that it can and reports that size:

    $ bigfile
    ..
    wrote 268 blocks
    bigfile: file is too small
    $

The test fails because `bigfile` expects to be able to create a file with 65,803 blocks, but unmodified xv6 limits files to 268 blocks.

You will change the xv6 file system code to support a "doubly-indirect" block in each inode, containing 256 addresses of singly-indirect blocks, each of which can contain up to 256 addresses of data blocks. The result will be that a file will be able to consist of up to 65,803 blocks, or 11+256+(256*256) blocks (11 instead of 12, because we will sacrifice one of the direct block numbers for the doubly-indirect block).

#### Preliminaries

The `mkfs` program creates the xv6 file system disk image and determines how many total blocks the file system has; this size is controlled by `FSSIZE` in `kernel/param.h`. You will see that `FSSIZE` in the repository for this assignment is set to 200,000 blocks. You should see the following output from `mkfs/mkfs` in the `make` output:

    nmeta 70 (boot, super, log blocks 30 inode blocks 13, bitmap blocks 25) blocks 199930 total 200000

This line describes the file system that `mkfs/mkfs` built: it has 70 meta-data blocks (blocks used to describe the file system) and 199,930 data blocks, totaling 200,000 blocks.

If at any point during the assignment you find yourself needing to rebuild the file system from scratch, you can run `make clean` which forces `make` to rebuild the file system image at `fs.img`.

#### What to Look At

The format of an on-disk inode is defined by `struct dinode` in `kernel/fs.h`. In this file, pay particular attention to `NDIRECT`, `NINDIRECT`, `MAXFILE`, and the `addrs[]` element of `struct dinode`. Look at Figure 8.3 in the [xv6 book](https://pdos.csail.mit.edu/6.828/2023/xv6/book-riscv-rev3.pdf) for a diagram of the standard xv6 inode.

The code that locates a file's data on disk is found in `bmap()` in `kernel/fs.c`. Take a look at it, and make sure you understand what it's doing. `bmap()` is called both when reading and writing a file. When writing, `bmap()` allocates new blocks as needed to hold file content, as well as allocating an indirect block if needed to hold block addresses.

`bmap()` deals with two kinds of block numbers. The `bn` argument is a "logical block number" -- a block number within a file relative to the start of the file, essentially an offset from the start of the file. The block numbers in `ip->addrs[]` and the argument to `bread()` are disk block numbers. You can view `bmap()` as mapping a file's logical block numbers (`bn`) onto disk block numbers (`ip->addrs[]`).

#### Your Job

Modify `bmap()` so that it implements 1 doubly-indirect block, in addition to 11 direct blocks and 1 singly-indirect block. You will need to have only 11 direct blocks, rather than 12, to make room for your new doubly-indirect block; you're not allowed to change the size of an on-disk inode. The first 11 elements of `ip->addrs[]` should be direct blocks; the 12th should be a singly-indirect block (just like the current one); the 13th should be your new doubly-indirect block. You are done with this exercise when `bigfile` writes 65,803 blocks and `usertests -q` runs successfully:

    $ bigfile
    ..................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................
    wrote 65803 blocks
    done; ok
    $ usertests -q
    ...
    ALL TESTS PASSED
    $ 

`bigfile` will take several minutes to run.

Some hints:

* Make sure that you understand `bmap()`. Write out a diagram of the relationships between `ip->addrs[]`, the indirect block, the doubly-indirect block and the singly-indirect blocks it points to, and the data blocks. Make sure you understand why adding a doubly-indirect block increases the maximum file size by 256*256 blocks (-1, since you have to decrease the number of direct blocks by one).
* Think about how you'll index the doubly-indirect block, and the indirect blocks it points to, using the logical block number (`bn`).
* You'll most likely need to change the definitions of both `NDIRECT` and `MAXFILE`.
* If you change the definition of `NDIRECT`, you'll probably have to change the declaration of `addrs[]` in `struct inode` in `kernel/file.h`. Make sure that `struct inode` and `struct dinode` have the same number of elements in their `addrs[]` arrays.
* If you change the definition of `NDIRECT`, make sure to create a new `fs.img`, since `mkfs` uses `NDIRECT` to build the file system.
* If your file system gets into a bad state, perhaps by crashing, delete `fs.img` (do this from Unix, not xv6). `make` will build a new clean file system image for you.
* Don't forget to call `brelse()` for each block that you `bread()`.
* You should allocate indirect blocks and doubly-indirect blocks only as needed, like the original `bmap()`.
* Make sure `itrunc` frees **all** blocks of a file, including doubly-indirect blocks.
* `usertests` will take MUCH longer to run than in previous assignments because, in this assignment, `FSSIZE` and big files are larger.


### 2. Add support for symbolic links

In this task, you will add support for symbolic links to xv6. A symbolic link (or soft link) refers to a *pathname* that points to a different file in the file system; when a symbolic link is opened, the kernel follows the link to the referred file. Symbolic links resemble hard links, but hard links are restricted to pointing to files on the same disk, while symbolic links can cross disk devices. Although xv6 doesn't support multiple devices, implementing this system call is a good exercise to understand how pathname lookup works.

You will implement the `symlink(char *target, char *path)` system call, which creates a new symbolic link at `path` that refers to the file named by `target`. For further information, see the `man` page for `symlink`. To test your implementation, add `symlinktest` to the `Makefile` and run it. Your solution is complete when the tests produce the following output (including `usertests` succeeding).

    $ symlinktest
    Start: test symlinks
    test symlinks: ok
    Start: test concurrent symlinks
    test concurrent symlinks: ok
    $ usertests -q
    ...
    ALL TESTS PASSED
    $ 

Some hints:

* First, create a new system call number for `symlink`, add an entry to `user/usys.pl`, `user/user.h`, `kernel/syscall.h`, and `kernel/syscall.c`, and implement an empty `sys_symlink` in `kernel/sysfile.c`.
* Add a new file type (`T_SYMLINK`) to `kernel/stat.h` to represent a symbolic link.
* Add a new flag to `kernel/fcntl.h`, (`O_NOFOLLOW`), that can be used with the `open` system call. Note that flags passed to `open` are combined using a bitwise `OR` operator, so your new flag should not overlap with any existing flags. This will let you compile `user/symlinktest.c` once you add it to the `Makefile`.
* Implement the `symlink(target, path)` system call to create a new symbolic link at `path` that refers to `target`. Note that `target` does not need to exist for the system call to succeed. You will need to choose somewhere to store the target path of a symbolic link, for example, in the inode's data blocks. `symlink` should return an integer representing success (0) or failure (-1) similar to `link` and `unlink`.
* Modify the `open` system call to handle the case where the path refers to a symbolic link. If the file does not exist, `open` must fail. When a process specifies `O_NOFOLLOW` in the flags to `open`, `open` should open the symlink itself (and not follow the symbolic link).
* If the linked file is also a symbolic link, you must recursively follow it until a non-linked file is reached. If the links form a cycle, you must return an error code. You may approximate this by returning an error code if the depth of links reaches some threshold (e.g., 10).
* Other system calls (e.g., `link` and `unlink`) must not follow symbolic links; these system calls operate on the symbolic link itself.
* You do not have to handle symbolic links to directories for this assignment.


## Disclosure of AI Usage

Create a file in the root of this directory called `ai-usage.txt` containing a disclosure of any Artificial Intelligence tools (e.g., ChatGPT) that you used in helping to complete this assignment. If you did not use any AI tools, simply include the sentence "I did not use AI in this assignment.".

Recall from the syllabus: "Any use of AI tools must be disclosed. This disclosure is a report that includes what AI tools you used, what it helped you with, and what it could not help you with. You will not be penalized for using AI tools, but **you may be penalized for inadequate or incomplete disclosure.**" This implies that you must describe **both** how it was effective AND how it was ineffective.


## Submission

This completes the assignment. Please run `make grade` to ensure that your code passes all of the preconfigured tests. Note that the `make grade` tests do not constitute **all** of the tests that your code may be subjected to for final grading, so make sure that each piece of your submission fully meets the specifications and criteria set forth in the tasks above. When you are ready, commit your changes with the message "Final Submission", and push the contents to GitHub to submit your assignment:

    $ git add *
    $ git commit -am "Final Submission"
    $ git push
